# jayrock09.github.io

Personal site for **jayrock09**.

- Home: `/`
- Links: `/link/`

YouTube: https://www.youtube.com/@jayrock0927  
Discord: https://discord.gg/qvprsaQfF
